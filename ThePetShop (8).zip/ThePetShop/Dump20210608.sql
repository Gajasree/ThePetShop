CREATE DATABASE  IF NOT EXISTS `userdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `userdb`;
-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: userdb
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `emailid` varchar(45) NOT NULL,
  `phonenumber` int DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES ('gaja','gaja','gaja@gmail.com',99765),('janani','janani','janani@gmail.com',9988776),('kamalam','kamalam','kam@gmail.com',95433),('sheela','sheela','sheela@gmail.com',99887),('suma','suma','suma@gmail.com',94536);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `productid` varchar(20) NOT NULL,
  `productname` varchar(45) NOT NULL,
  `productprice` varchar(45) NOT NULL,
  PRIMARY KEY (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('CAC01','Cat Collar (Blue)','280'),('CAC02','Trixie Nylon Harness(Red)','250'),('CAC03','Mutt Feline Print Cat Bow Tie (Pink)','200'),('CAC04','Cat Collar (Purple)','180'),('CAC05','Trixie Harness For Kittens (Black)','380'),('CAC06','Food Bowl For Cats - White','320'),('CAC07','Harness For Kittens (Blue)','260'),('CAC08','Fun Feeder Spiral Slow Feeding Bowl For Cats','225'),('CAD01','Persian Cat','15000'),('CAD02','Munchkin Cat','20000'),('CAD03','Japanese Bobtail','30000'),('CAD04','Exotic Shorthair','25000'),('CAD05','American Bobtail','35000'),('CAD06','Turkish Angora','28000'),('CAD07','Manx Cat','18000'),('CAD08','Burmilla','24000'),('CFO01','Farmina Matisse Cat Wet Food','200'),('CFO02','Acana Pacifica Cat Food','275'),('CFO03','Me-O Persian Adult Cat Food','300'),('CFO04','Versele-Laga Adult Cat Food','210'),('CFO05','Whiskas Pocket Ocean Fish Adult Cat Food','250'),('CFO06','Whiskas Tuna In Jelly Wet Food For Adult Cats','275'),('CFO07','Me-O Adult Mackerel In Jelly Cat Food','310'),('CFO08','Orijen Cat & Kitten Cat Food','280'),('CHE01','My Beau Cat Supplement','400'),('CHE02','Beaphar Irish Calcium And Bone Builder','425'),('CHE03','Beaphar Salmon Oil For Cats','450'),('CHE04','Bone Builder 500gm + My Beau Oil ','475'),('CHE05','Cat Supplement (Syrup)','430'),('CHE06','Calcium Bone Jar Cat Supplement','457'),('CHE07','Drools Absolute Salmon Oil','399'),('CHE08','Calcium Cat Supplement Tablets','370'),('DAC01','Durable Rope Training Leash For Dogs (Red)','300'),('DAC02','Trixie Premium Nylon Dog Collar (Jet Black)','250'),('DAC03','Donut Shaped Repellent (Blue & Yellow)','275'),('DAC04','Trixie Dog Harness (Royal Blue)','200'),('DAC05','Dog Chain Stainless Steel Leash','220'),('DAC06','PoochMate Pink Doby Bow Tie','260'),('DAC07','Stainless Steel Dog Bowl','255'),('DAC08','Mutt Of Course Toffee Print Dog Bow Tie','285'),('DAD01','German Shepherd','10000'),('DAD02','Bulldog','12000'),('DAD03','Labrador Retriever','5000'),('DAD04','Golden Retriever','12000'),('DAD05','Pomeranian','7000'),('DAD06','Shih Tzu','30000'),('DAD07','Maltese Dog','50000'),('DAD08','Samoyed','60000'),('DFO01','SmartHeart Chicken Dog Food','200'),('DFO02','Drools Ultium Performance Dry Dog Food','150'),('DFO03','Pedigree Chicken Dog Food','175'),('DFO04','Acana Adult Large Breed Dry Dog Food','100'),('DFO05','Arden Grange Dog Food','125'),('DFO06','Fresh For Paws Dog Food (Chicken Stew)','130'),('DFO07','Himalaya Adult Dog Food - Meat & Rice','110'),('DFO08','Acana Free-Run Duck Dog Food','160'),('DHE01','Beaphar Doggy\'s Biotine Tablets','400'),('DHE02','Beaphar HD Tablets For Dogs','450'),('DHE03','Beaphar Kalk Tablets','475'),('DHE04','Dog Beaphar160 Tabs','500'),('DHE05','Dog Supplement Combo Beaphar Kalk','410'),('DHE06','My Beau Oil + Beaphar HD For Joint','435'),('DHE07','My Beau Pala Mountains Dog Supplement 300ml','480'),('DHE08','Beaphar Bone Builder + Drools Skin','415'),('FAC01','Aquarium Air Stone','800'),('FAC02','Bridge On Hills Aquarium Decoration Ornaments','1000'),('FAC03',' Pet Products Fish Tank Decorative Ornaments','600'),('FAC04','Ship Resin Wreck Small Net Ship Aquarium','700'),('FAC05','Aquarium Decor Ornaments','650'),('FAC06','Cichlid Stone Pond Ornament','780'),('FAC07','Turtle Ornament For Tank Decoration','879'),('FAC08','Mushroom Ornament For Fish Tank','657'),('FAD01','Betta','40'),('FAD02','Goldfish','12'),('FAD03','Angelfish','10'),('FAD04','Catfish','25'),('FAD05','Guppy','50'),('FAD06','Molly','42'),('FAD07','Neon Tetra','60'),('FAD08','Swordtail','55'),('FFO01','Horizone Royal Feed Betta Fish','400'),('FFO02','Petzlifeworld Betta Feed, 20g','425'),('FFO03','Betta Vacation Feed Food','450'),('FFO04','Aura The Healthy Betta Protein Food, 25G','480'),('FFO05','Quality Shrimp Fish Food','499'),('FFO06','Optimum Betta Fish Food 20 Gms','380'),('FFO07','Taiyo Tropical Flakes Fish Food, 25 g','375'),('FFO08','Optimum Aquarium Fish Highly Nutritious Food','360'),('FHE01','Tetra Guppy 100 ml','300'),('FHE02','Alcoa Prime 1 Bag Package','321'),('FHE03','Absolute Nutrition Fish Oil','345'),('FHE04','Optimum Nutrition - Enteric-Coated Fish Oil','365'),('FHE05','Salmon Fish Oil','387'),('FHE06','Omega 3 Supplement','267'),('FHE07','Nature Made Fish Oil','432'),('FHE08','High Strength Wild Fish Oil','378');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-08 16:33:05
