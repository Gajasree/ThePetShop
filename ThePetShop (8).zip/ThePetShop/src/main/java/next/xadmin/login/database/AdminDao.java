package next.xadmin.login.database;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import next.xadmin.login.bean.AdminBean;
import next.xadmin.login.bean.AdminProductBean;
import next.xadmin.login.bean.ProductBean;

public class AdminDao {
	
	
	public boolean validate(AdminBean adminBean)
	{
		boolean status = false;
		
		
		Connection con = ConnectionDemo.getConnection();
		
		String sql = "select * from adminlogin where username = ? and password =?";
		PreparedStatement ps;
		try {
		ps = con.prepareStatement(sql);
		ps.setString(1, adminBean.getUsername());
		ps.setString(2, adminBean.getPassword());
		ResultSet rs = ps.executeQuery();
		status = rs.next();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}
	
public List<AdminProductBean> getCart(){
		
		Connection con  = ConnectionDemo.getConnection();
		PreparedStatement preparedStatement=null;
		List<String> itemCodeList = new ArrayList<String>();
		List<AdminProductBean> productList = new ArrayList<AdminProductBean>();
		int result = 0;
		try {
			preparedStatement = con.prepareStatement("select item_code,username from cart where ordered=?");
			preparedStatement.setString(1, "yes");
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) {
				itemCodeList.add(rs.getString(1)+","+rs.getString(2));
			}
			System.out.println(itemCodeList);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in getcart admin");
		}
		try {
			int total = 0;
			for(String itemCode : itemCodeList) {
				String arr[]=itemCode.split(",");
				String itemCode1 = arr[0];
				String userName1= arr[1];
				preparedStatement = con.prepareStatement("select * from products where productid=?");
				preparedStatement.setString(1, itemCode1);				
				ResultSet rs = preparedStatement.executeQuery();
				
				if(rs.next()) {					
				//	total = rs.getInt(3)+total;
					productList.add(new AdminProductBean(rs.getString(1), rs.getString(2), rs.getInt(3),userName1));
				}
			}
			System.out.println(productList);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Product List");
		}
		return productList;
	}
	}
