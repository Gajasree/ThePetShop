package next.xadmin.login.bean;

public class ProductBean {
	
	private String productid;
	private String productname;
	private int productprice;
	private int total;
	public ProductBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductBean(String productid, String productname, int productprice) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productprice = productprice;
	}
	
	public ProductBean(String productid, String productname, int productprice, int total) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productprice = productprice;
		this.total = total;
	}
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public int getProductprice() {
		return productprice;
	}
	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}
	
	
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "ProductBean [productid=" + productid + ", productname=" + productname + ", productprice=" + productprice
				+ ", total=" + total + "]";
	}
	
	
	
}