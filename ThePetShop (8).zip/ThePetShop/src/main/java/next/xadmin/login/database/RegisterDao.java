
package next.xadmin.login.database;




	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;

	import next.xadmin.login.bean.RegisterBean;

	public class RegisterDao {
		
		
		public boolean validate(RegisterBean registerBean)
		{
			boolean status = false;					
			Connection con = ConnectionDemo.getConnection();
			
			String sql = "insert into login (username,password,emailid,phonenumber) values(?,?,?,?)";
			PreparedStatement ps;
			try {
			ps = con.prepareStatement(sql);
			ps.setString(1, registerBean.getUsername());
			ps.setString(2, registerBean.getPassword());
			ps.setString(3, registerBean.getEmailid());
			ps.setString(4, registerBean.getPhonenumber());
			//ResultSet rs = ps.executeQuery();
			int result=ps.executeUpdate();
			//status = rs.next();
			if(result!=0) {
				status=true;
			}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return status;
		}
		}
