package next.xadmin.login.bean;

public class AdminProductBean {
	
	private String productid;
	private String productname;
	private int productprice;
	private String userName;
	public AdminProductBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AdminProductBean(String productid, String productname, int productprice) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productprice = productprice;
	}
	
	public AdminProductBean(String productid, String productname, int productprice, String userName) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productprice = productprice;
		this.userName = userName;
	}
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public int getProductprice() {
		return productprice;
	}
	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "AdminProductBean [productid=" + productid + ", productname=" + productname + ", productprice="
				+ productprice + ", userName=" + userName + "]";
	}
	
	
	
	
	
}