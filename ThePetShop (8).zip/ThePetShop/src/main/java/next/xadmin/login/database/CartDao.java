package next.xadmin.login.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import next.xadmin.login.bean.ProductBean;

public class CartDao {

	public int addCart(String itemCode,String username) {
		
		Connection con  = ConnectionDemo.getConnection();
		PreparedStatement preparedStatement=null;
		int result = 0;
		try {
			preparedStatement = con.prepareStatement("insert into cart (item_code,username)values(?,?)");
			preparedStatement.setString(1, itemCode);
			preparedStatement.setString(2, username);
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in add Cart.. "+e);
		}
		return result;
	}
	
	public List<ProductBean> getCart(String username){
		
		Connection con  = ConnectionDemo.getConnection();
		PreparedStatement preparedStatement=null;
		List<String> itemCodeList = new ArrayList<String>();
		List<ProductBean> productList = new ArrayList<ProductBean>();
		int result = 0;
		try {
			preparedStatement = con.prepareStatement("select item_code from cart where username=? and ordered=?");
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, "no");
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) {
				itemCodeList.add(rs.getString(1));
			}
			System.out.println(itemCodeList);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in getting item code");
		}
		try {
			int total = 0;
			for(String itemCode : itemCodeList) {
				preparedStatement = con.prepareStatement("select * from products where productid=?");
				preparedStatement.setString(1, itemCode);				
				ResultSet rs = preparedStatement.executeQuery();
				
				if(rs.next()) {					
					total = rs.getInt(3)+total;
					productList.add(new ProductBean(rs.getString(1), rs.getString(2), rs.getInt(3),total));
				}
			}
			System.out.println(productList +"\t"+"total :"+total);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Product List");
		}
		return productList;
	}
	
	public void removeCart(String itemCode,String userName) {
		Connection con  = ConnectionDemo.getConnection();
		PreparedStatement preparedStatement=null;		
		int result = 0;
		try {
			preparedStatement = con.prepareStatement("delete from cart where item_code=? and username=? limit 1");
			preparedStatement.setString(1, itemCode);
			preparedStatement.setString(2, userName);
			result = preparedStatement.executeUpdate();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in delete cart item");
		}
	}
	
	public void purchaseConfirm(String userName) {
		Connection con  = ConnectionDemo.getConnection();
		PreparedStatement preparedStatement=null;		
		int result = 0;
		try {
			preparedStatement = con.prepareStatement("update cart set ordered=? where username=?");
			preparedStatement.setString(1, "yes");
			preparedStatement.setString(2, userName);
			result = preparedStatement.executeUpdate();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in purchaseConfirm cart item");
		}
	}
	
}
